#!/usr/bin/env python
import operator
from random import choice, randint

operators = {
    '+' : operator.add,
    '*': operator.mul,
    "-": operator.sub,
}
operators_list = list(operators.keys())
TASK = 'What is the result of the expression?'


def question_generation():
    number_1 = randint(1, 100)
    number_2 = randint(1, 100)
    operator_key = choice(operators_list)
    # current_operator = operators.get(operator_key)
    # question = '{} {} {} '.format(number_1, operator_key, number_2)
    question = number_1, operator_key, number_2
    return question


def answer(question):
    q = question
    current_operator = operators.get(q[1])
    correct_answer = current_operator(q[0], q[2])
    return correct_answer


def question(question):
    question = '{} {} {}'.format(question[0], question[1], question[2])
    return question




 
