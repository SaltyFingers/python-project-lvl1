#!/usr/bin/env python

from brain_games.games.game_gcd import gcd_logic


def main():
    gcd_logic()


if __name__ == "__main__":
    main()
