#!/usr/bin/env python

from brain_games.games.game_calc import calc_logic


def main():
    calc_logic()


if __name__ == "__main__":
    main()
