
import random

import prompt
from brain_games.scripts.common_logic import welcome_user 


def progression_logic():
    name = welcome_user()
     i = 0
    print('What number is missing in the progression?')
    for i in range(3):
        x = random.randint(1, 10)
        n = random.randint(1, 10)
        for number in range(10):
        number = x + n
        progression = []
        progression = progression + number
        print(progression)
    return pro gression
print(progression)
