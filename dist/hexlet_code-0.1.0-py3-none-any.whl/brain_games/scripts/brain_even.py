#!/usr/bin/env python

from brain_games.logic import even_logic

def main():
    even_logic()


if __name__ == "__main__":
    main()